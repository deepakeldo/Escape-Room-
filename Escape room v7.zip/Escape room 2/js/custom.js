/*---------------------------------------------------------------------
    File Name: custom.js
---------------------------------------------------------------------*/


/* collapse js*/


function goToAllGames() {
  window.location.href = 'allgames.html';
  console.log("clicked start");

}
function goToCrossword() {
  window.location.href = 'crossword.html';

}
function goToPuzzle() {
  window.location.href = 'puzzle.html';

}
function goToMatching() {
  window.location.href = 'matching.html';

}
function goToQuiz() {
  window.location.href = 'quiz.html';
}
function goToLogicQuiz() {
  window.location.href = 'logicgate.html';
}
function goToSnakeGame() {
  window.location.href = 'snake.html';
}
